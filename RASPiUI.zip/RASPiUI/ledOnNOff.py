import time, sys, RPi.GPIO as GPIO

GPIO.setmode(GPIO.BOARD)

GPIO.setup(11,GPIO.OUT)

GPIO.setwarnings(False)

try :
    if(sys.argv[1] == "on") :
        GPIO.output(11, True)
    elif(sys.argv[1] == "off") :
        GPIO.output(11, False)    
except Exception as ex :
    print("Got Exception : "+ex)