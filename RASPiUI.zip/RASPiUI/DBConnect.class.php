<?php
class DBConnect {
	
	private $ini_array;
	private $mysql;
	private $logObj;
	
	public function __construct($ini_array, $logObj) {
		$this->logObj = $logObj;
		$this->ini_array = $ini_array;
	}
	
	public function getConnection() {
		$this->logObj->debug("Inside getConnection : ");
		
		$this->mysql = new mysqli($this->ini_array['DB_HOST'],$this->ini_array['DB_USER'],$this->ini_array['DB_PASSWORD'],$this->ini_array['DB_NAME']);
		
		if ($this->mysql->connect_error) {
    		$this->logObj->debug("Connection Failed: " . $conn->connect_error);
    		return false;
		} else {
			$this->logObj->debug("Connection Successful");
			return true;
		}
	}
	
	public function insertRows($tableName,$rowArray) {
		if(count($rowArray) == 0) {
			return false;
		}
		$sqlQuery = "INSERT INTO ".$tableName."(`";
		$keys = implode("`,`", array_keys($rowArray[0]));
		$sqlQuery .= $keys."`) VALUES ";
		
		
		for($i=0;$i<count($rowArray);$i++) {
			$values = array_values($rowArray[$i]);
			$sqlQuery .= "('".implode("','", $values)."'),";
		}
		
		$sqlQuery = substr($sqlQuery, 0 , strlen($sqlQuery)-1);
		
		$this->logObj->debug("Insert Query : ".$sqlQuery);
		
		if($this->getConnection()) {
			if ($this->mysql->query($sqlQuery) === TRUE) {
    			$this->logObj->debug("New record created successfully");
			} else {
    			$this->logObj->debug("Error: " . $sql . "<br>" . $this->mysql->error);
			}
			$this->mysql->close();
			
			// REMOVE THIS ....
			// $this->fetchRows($tableName);
			
			return true;			
		} else {
			$this->logObj->debug("Getting DB Connection Failed ....");
			return false;
		}
	}
	
	public function fetchRows($tableName, $selectArray=array() , $whereCondition = "") {
		$sqlQuery = "SELECT ";
		if(count($selectArray) == 0) {
			$sqlQuery .= "* ";
		} else {
			$sqlQuery .= implode(",",$selectArray)." ";
		}
		
		$sqlQuery .= "FROM ".$tableName;
		
		if(strlen($whereCondition) != 0) {
			$sqlQuery .= " WHERE ".$whereCondition;
		}
		
		$this->logObj->debug("Fetch Query : ".$sqlQuery);
		
		if($this->getConnection()) {
			$retVal = '{"actions" : ';
			$result = $this->mysql->query($sqlQuery);
			
			if ($result->num_rows > 0) {
				$resultArr = array();
				 
    			while($row = $result->fetch_assoc()) {
		    	   	$resultArr[] = $row;
	    		}
	    		
	    		$retVal .= json_encode($resultArr);
	    		
			} else {
    			$this->logObj->debug("0 results");
    			$retVal .= '[]';
			}
			
			$this->mysql->close();
			
			$this->logObj->debug($retVal.'}');
			
			return $retVal.'}';			
		} else {
			return '{"actions" : []}';
		}
	}
}
?>