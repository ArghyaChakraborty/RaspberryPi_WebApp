<?php
include_once 'log4j.php';
include_once 'DBConnect.class.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Check all the oncoming request here ....
if(array_key_exists("method", $_GET)) {
	if($_GET["method"] == "getLEDStatus") {
		echo getLEDStatus();
	} else if($_GET["method"] == "setLEDStatus") {
		echo setLEDStatus($_GET["ledStatus"]);
	} 
	else if($_GET["method"] == "getTempNHumidData") {
		echo getTempNHumidData();
	}
	else if($_GET["method"] == "logAction") {
		echo logAction($_GET["message"],$_GET["note"]);
	}
	else if($_GET["method"] == "getPastActions") {
		echo getPastActions();
	}
	else if($_GET["method"] == "actOnRaspi") {
		echo actOnRaspi($_GET["action"]);
	}
}

// All function definitions go here ..
// Function to get LED Status
function getLEDStatus() {
	global $ini_array , $logObj;
	$logObj->debug("Inside getLEDStatus");
	$ledStatus = file_get_contents($ini_array["LED_STATUS_FILE"]);
	$logObj->debug("LED Status = "+$ledStatus);
	return json_encode('{"status" : "'.$ledStatus.'"}');
}

// Function to set LED Status
function setLEDStatus($status) {
		// $status = true / false
	global $ini_array , $logObj;
	$logObj->debug("Inside setLEDStatus :  status : ".$status);
	
	$fp = fopen($ini_array["LOCK_FILE"], "w");
	$returnValue = "";

	if (! flock($fp, LOCK_EX)) {  // acquire an exclusive lock
		$logObj->debug("Unable to acquire lock ....");
    	$returnValue = "Sorry ... someone else is trying to light the LED .....";
	} else {
		$pyCommand = "sudo ".$ini_array["PYTHON_PATH"]." ".$ini_array["SET_LED_STATUS_SCRIPT"]." ";
		$f2w = fopen($ini_array["LED_STATUS_FILE"], "w");
	
		if($status == "on") {
			exec($pyCommand."on", $output, $retVal);
			$logObj->debug("Tried to swich on the LED.\nScript O/P : ".print_r($output,true)."\nScript Status : ".$retVal);
			fwrite($f2w, "on");
			$returnValue = "on";
		} else if ($status == "off"){
			exec($pyCommand."off", $output, $retVal);
			$logObj->debug("Tried to swich off the LED.\nScript O/P : ".print_r($output,true)."\nScript Status : ".$retVal);
			fwrite($f2w, "off");
			$returnValue = "off";
		}
	
		fclose($f2w);
		fclose($fp);
    	flock($fp, LOCK_UN);    // release the lock
    	fclose($fp);	
	}

	return json_encode('{"status" : "'.$returnValue.'"}');
}

// Function to retrieve Time Series Data from DB
function getTempNHumidData($startDate="",$startTime="",$endDate="",$endTime="") {
	global $logObj;
	$logObj->debug("Inside getTempNHumidData");
	$jsonData = '{';
	$jsonData .= '"rows" : [{"year" : 2016,"month" : 12,"date" : 13,"hour" : 10,"min" : 20,"sec" : 30,"temp" : -15,"humidity" : 30},{"year" : 2016,"month" : 12,"date" : 13,"hour" : 11,"min" : 20,"sec" : 30,"temp" : -14,"humidity" : 35},{"year" : 2016,"month" : 12,"date" : 13,"hour" : 12,"min" : 20,"sec" : 30,"temp" : -15.2,"humidity" : 35},{"year" : 2016,"month" : 12,"date" : 13,"hour" : 12,"min" : 20,"sec" : 30,"temp" : -15.2,"humidity" : 33},{"year" : 2016,"month" : 12,"date" : 15,"hour" : 12,"min" : 20,"sec" : 30,"temp" : -15.2,"humidity" : 33}]';
	$jsonData .= ',"maxTemp" : -14';
	$jsonData .= ',"minTemp" : -15.2';
	$jsonData .= ',"maxHumidity" : 35';
	$jsonData .= ',"minHumidity" : 30';
	$jsonData .= ',"maxTempDate" : "2016-12-13"';
	$jsonData .= ',"minTempDate" : "2016-12-13"';
	$jsonData .= ',"maxHumidityDate" : "2016-12-13"';
	$jsonData .= ',"minHumidityDate" : "2016-12-13"';
	$jsonData .= ',"fromDate" : "2016--12-13"';
	$jsonData .= ',"toDate" : "2016-12-15"';
	$jsonData .= '}';
	return json_encode($jsonData);
}

// Function to write Action Details to DB
function logAction($message, $note) {
	global $logObj , $ini_array;
	$logObj->debug("inside PHP logAction");
	$currDate = date("Y-m-d H:i:s");
	$ip = "";
	
	if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	} else {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	
	$logObj->debug("inside PHP logAction ".$currDate." =========== ".$ip);
	
	$db = new DBConnect($ini_array, $logObj);
	$rowArray = array();
	$tempArray = array();
	$tempArray['date'] = $currDate;
	$tempArray['ip'] = $ip;
	$tempArray['action'] = $message;
	if(strlen($note) != 0) {
		$tempArray['note'] = $note;
	}
	
	$rowArray[] = $tempArray;
	
	$retNote = "";
	if(!$db->insertRows($ini_array['DB_TABLE_NAME'], $rowArray)) {
		$retNote = "Logging Failed";
	} else {
		$retNote = "NA";
	}
	
	$retval = '{"date" : "'.$currDate.'" , "ip" : "'.$ip.'" , "note" : "'.$retNote.'"}';
	$logObj->debug("retVal = ".$retval);
	return json_encode($retval);
} 

// Function for initial load of all existing audit data
function getPastActions() {
	global $logObj,$ini_array;
	$logObj->debug("Inside getPastActions");
	
	// Code to retrieve data from DB goes here
	$db = new DBConnect($ini_array, $logObj);
	$pastActions = $db->fetchRows($ini_array['DB_TABLE_NAME']);
	
	/*
	$pastActions = '{"actions" : [';
	$pastActions .= '{"dateTime" : "2016-12-13 12:00:00" , "ip" : "127.0.0.1" , "message" : "Dummy1" , "note" : "NA"}';
	$pastActions .= ' , {"dateTime" : "2016-12-14 12:00:00" , "ip" : "127.0.0.1" , "message" : "Dummy2" , "note" : "NA"}';
	$pastActions .= ']}';
	*/
	
	return json_encode($pastActions);
}

// Function to perform action on Raspberry Pi
function actOnRaspi($action) {
	// Code to act on Raspberry PI go here
	global $logObj, $ini_array;
	$logObj->debug("Inside actOnRaspi .. Action : ".$action);
	$pyCommand = "sudo ".$ini_array["PYTHON_PATH"]." ".$ini_array["RASPI_ACTION_SCRIPT"]." ".$action;
	$logObj->debug("Raspi Action Command : ".$pyCommand);
	exec($pyCommand, $output, $retVal);
	$logObj->debug("Raspi Action Command RetCode: ".$retVal." , Output : ".$output);
	return json_encode('{}');
}
?>