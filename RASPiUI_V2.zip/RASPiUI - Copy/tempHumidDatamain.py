import sys
import RPi.GPIO as GPIO
import os
from time import sleep
from datetime import datetime
import Adafruit_DHT

from pubnub.pnconfiguration import PNConfiguration
from pubnub.pubnub import PubNub

from ConfigParser import ConfigParser
import MySQLdb

DHTpin = 0
myDelay = 0
PUBLISH_KEY = ""
SUBSCRIBE_KEY= ""
CHANNEL_NAME = ""
dbHost = ""
dbUser = ""
dbPassword = ""
dbName = ""
DB_TABLE_NAME_TNH = ""
pubnub = object()


# Read and set configuration values
def initializeConfigs() :
    global DHTpin, myDelay, PUBLISH_KEY , SUBSCRIBE_KEY , CHANNEL_NAME , dbHost , dbUser , dbPassword , dbName , DB_TABLE_NAME_TNH , pubnub
    
    config = ConfigParser()
    config.readfp(open("/var/www/html/RASPi/config.ini"))

    DHTpin = int(config.get("Python_TNH","DHT11_PIN")) # 23 # Setup the pins we are connect to ###### 
    myDelay = int(config.get("Python_TNH", "DHT11_READ_DELAY")) # 15 #how many seconds between posting data ###################
    GPIO.setmode(GPIO.BCM)
    PUBLISH_KEY = config.get("Python_General","PUBNUB_PUBLISH_KEY") # 'sub-c-24840304-c741-11e6-b8a7-0619f8945a4f' ###############
    SUBSCRIBE_KEY= config.get("Python_General", "PUBNUB_SUBSCRIBE_KEY") # 'pub-c-06daeb79-d545-42b4-ba08-d97821302c7b' ############
    CHANNEL_NAME = config.get("Python_TNH","PUBNUB_CHANNEL_NAME_TNH") # 'such_channel' ################
    dbHost = config.get("General", "DB_HOST") # "localhost"
    dbUser = config.get("General", "DB_USER") # "root"
    dbPassword = config.get("General", "DB_PASSWORD") # "arghya"
    dbName = config.get("General", "DB_NAME") # "raspi"
    DB_TABLE_NAME_TNH = config.get("Python_TNH", "DB_TABLE_NAME_TNH") # TEMP_HUMID_DATA
    
    pnconfig = PNConfiguration()
 
    pnconfig.subscribe_key = SUBSCRIBE_KEY
    pnconfig.publish_key = PUBLISH_KEY
 
    pubnub = PubNub(pnconfig)
    
# get sensor Data from DHT11
def getSensorData():
    global DHTpin
    
    RHW, TW = Adafruit_DHT.read_retry(Adafruit_DHT.DHT11, DHTpin)
    
    #Convert from Celius to Farenheit
    # TWF = 9/5*TW+32
   
    # return dict
    # return (str(RHW), str(TW),str(TWF))
    return (str(RHW), str(TW))

# Handle PNPublishResult and PNStatus
def publish_callback(result, status):
    print(result,status)
    
# Method to publish Data to PubNub
def publishSensorData(humidity,temparature):
    global pubnub
    
    currDate = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
     

    # pubnub.publish().channel('such_channel').message(['hi', 'there']).async(publish_callback)
    pubnub.publish().channel(CHANNEL_NAME).message({"Date" :  currDate,"Temparature" : temparature ,"Humidity" : humidity}).async(publish_callback)
    
    return currDate

# Method to insert temperature and humidity Data to DB
def insertRowsInDB(dateNTime,temparature,humidity):
    global dbHost , dbUser , dbPassword , dbName , DB_TABLE_NAME_TNH
    
    conn = MySQLdb.connect(host= dbHost, user=dbUser, passwd=dbPassword, db=dbName)
    x = conn.cursor()
    
    try:
        x.execute("INSERT INTO "+DB_TABLE_NAME_TNH+"(`datetime`,`temparature`,`humidity`) VALUES ('"+dateNTime+"',"+temparature+","+humidity+")")
        conn.commit()
    except:
        conn.rollback()

    conn.close()
    
    
    
# main() function
def main():
    initializeConfigs()
    
    while True:
        try:
            # RHW, TW, TWF = getSensorData()
            RHW, TW = getSensorData()
            # print TW + " " + TWF+ " " + RHW
            
            publishDateNTime = publishSensorData(RHW, TW)
            
            insertRowsInDB(publishDateNTime, TW, RHW)
            
            sleep(int(myDelay))
        except:
            print 'exiting.'
            sys.exit()
        
        
if __name__ == "__main__" :
    main()