#!/usr/bin/python
import sys, os

try :
    if(sys.argv[1] == "Reboot") :
        os.system("sudo reboot");
    elif(sys.argv[1] == "Shutdown") :
         os.system("sudo shutdown now")
except Exception as ex :
    print("Got Exception : "+ex)