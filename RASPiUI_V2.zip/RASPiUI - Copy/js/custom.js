/**
 * This JS file contain all Angular Module Definitions
 */
var app = angular.module("raspiApp", ["ngRoute"]);

app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "dashboard.htm",
        controller : "dashboardController"
    })
    .when("/dashboard", {
        templateUrl : "dashboard.htm",
        controller : "dashboardController"
    })
    .when("/actions", {
        templateUrl : "actions.htm",
        controller : "actionsController"
    })
    .when("/commandutil", {
        templateUrl : "commandutil.htm",
        controller : "commandUtilController"
    })
    .otherwise({
        templateUrl : "undefined.htm"
    });
});


//This controller takes responsibility of Command Util Page
app.controller("commandUtilController", function($scope,$http) {
	$scope.CMDOP = "";
	$scope.CMD = "";
	// Function to execute OS commands
	$scope.executeCommand = function() {
		// console.log("Inside commandUtilController.executeCommand() == "+$scope.CMD);
		$scope.CMDOP = "";
		if($scope.CMD == "") {return false;}
	    $http.get("util.php?method=executeCommand&command="+$scope.CMD)
	    .then(function(response) {
	    	// console.log("HTTP Response : "+response.data);
	        cmdOp = JSON.parse(response.data);
	        var cmdOpStr = "";
	        for(i=0;i<cmdOp['output'].length;i++) {
	        	cmdOpStr += cmdOp['output'][i]['line']+"<br/>";
	        }
	        // console.log(cmdOpStr);
	        // $scope.CMDOP = cmdOpStr;
	        document.getElementById("editor").innerHTML = cmdOpStr;
	    });
	};
});


// This controller takes command from all the action items
app.controller("actionsController", function($scope,$http) {
	// Create an instance of Data Table
	$scope.auditTable = $('#datatable').DataTable();
	
	// HTTP request to fetch current LED Status
    $http.get("util.php?method=getLEDStatus")
    .then(function(response) {
        ledStatus = JSON.parse(response.data);
        if(ledStatus['status'] == "on") {
        	$("#myonoffswitch").prop('checked', true);
        	$scope.switchVal = true;
        } else {
        	$("#myonoffswitch").prop('checked', false);
        	$scope.switchVal = false;
        }
    });
    
    // HTTP request to fetch current DHT11 Status
    $http.get("util.php?method=getDHT11Status")
    .then(function(response) {
        var status = JSON.parse(response.data);
        console.log("Inside GetDHT11Status : Response  == "+response.data);
        if(status['status'] == "connected") {
        	$("#dhtonoffswitch").prop('checked', true);
        	$scope.dhtswitchVal = true;
        } else {
        	$("#dhtonoffswitch").prop('checked', false);
        	$scope.dhtswitchVal = false;
        }
    });
    
    // HTTP Request to fetch All Audit Actions
    $http.get("util.php?method=getPastActions")
    .then(function(response) {
    	// console.log("Inside getPastActions : "+response.data);
        pastActions = JSON.parse(response.data);
        
        for(i=0;i<pastActions['actions'].length;i++) {
        	$scope.addAuditTableRow(pastActions['actions'][i]['date'],pastActions['actions'][i]['ip'],pastActions['actions'][i]['action'],pastActions['actions'][i]['note']);
        }
    });
    
    // Function to turn the LED on/off based on user action
	$scope.changeLedStatus = function() {
		// console.log("Inside actionsController.changeLedStatus");
		var ledStatus = "";
		if($scope.switchVal) {
			ledStatus = "on";
		} else {
			ledStatus = "off";
		}
		
		$scope.logAction("LED Turned "+ledStatus,"");
		
		
	    $http.get("util.php?method=setLEDStatus&ledStatus="+ledStatus)
	    .then(function(response) {
	        ledStatus = JSON.parse(response.data);
	        if(ledStatus['status'] == "on") {
	        	$("#myonoffswitch").prop('checked', true);
	        	$scope.switchVal = true;
	        } else {
	        	$("#myonoffswitch").prop('checked', false);
	        	$scope.switchVal = false;
	        }
	    });
	    
	};
	
	
	// Function to act on Raspberry Pi : Shutdown / Reboot etc
	$scope.actOnRasPi = function() {
		var actionSelect = document.getElementById("raspiAction");
		var action = actionSelect.options[actionSelect.selectedIndex].value;
		// console.log("Inside actionsController.actOnRasPi. Action : "+action);
		
		if(action == "") {return false;}
		
		$scope.logAction(action,"");
		
		$http.get("util.php?method=actOnRaspi&action="+action)
	    .then(function(response) {
	    	document.getElementById("raspiAction").value = "";
	    });
	};
	
    // Function to turn the DHT11 on/off based on user action
	$scope.changeDHTStatus = function() {
		// console.log("Inside actionsController.changeLedStatus");
		var dhtStatus = "";
		if($scope.dhtswitchVal) {
			dhtStatus = "connected";
		} else {
			dhtStatus = "disconnected";
		}
		
		$scope.logAction("DHT11 "+dhtStatus,"");
		
		
	    $http.get("util.php?method=setDHTStatus&status="+dhtStatus)
	    .then(function(response) {
	    	console.log("Set DHT Status : GET Response - "+response.data);
	        status = JSON.parse(response.data);
	        /*
	        if(status['status'] == "connected") {
	        	// $("#dhtonoffswitch").prop('checked', true);
	        	// $scope.dhtswitchVal = true;
	        } else {
	        	// $("#dhtonoffswitch").prop('checked', false);
	        	// $scope.dhtswitchVal = false;
	        }
	        */
	    });
	    
	};
	
	
	// Function to log Action taken on Actions page in DB
	$scope.logAction = function(message,note) {
		// console.log("Inside logAction with : "+message);
		$http.get("util.php?method=logAction&message="+message+"&note="+note)
	    .then(function(response) {
	    	var retVal = JSON.parse(response.data);
	    	var dateTime = retVal['date'];
	    	var ip = retVal['ip'];
	    	var note = retVal['note'];
	    	$scope.addAuditTableRow(dateTime,ip,message,note);
	    });
	};
	
	// Function to add Rows in Audit Table
	$scope.addAuditTableRow = function(dateTime,ip,message,note) {
		// console.log("Insode addAudit Table Row");
    	$scope.auditTable.row.add( [
    	   	    	             dateTime,
    	   	    	             ip,
    	   	    	             message,
    	   	    	             note
    	   	    	         ] ).draw( false );
	};
});


//This controller fetches data to prepare all dashboards
app.controller("dashboardController", function($scope, $http, $window) {
	// console.log("Inside dashboardController");
	// Http request to fetch time series data from DB
    $http.get("util.php?method=getTempNHumidData")
    .then(function(response) {
    	// console.log("Inside dashboardController http get : "+response.data);	
    	
    	$scope.thRecords = JSON.parse(response.data);
        
    	$scope.MAXTEMP = $scope.thRecords["maxTemp"];
    	$scope.MAXTEMPDATE = $scope.thRecords["maxTempDate"].split(" ")[0];
    	$scope.MAXHUMIDITY = $scope.thRecords["maxHumidity"];
    	$scope.MAXHUMIDITYDATE = $scope.thRecords["maxHumidityDate"].split(" ")[0];
    	$scope.MINTEMP = $scope.thRecords["minTemp"];
    	$scope.MINTEMPDATE = $scope.thRecords["minTempDate"].split(" ")[0];
    	$scope.MINHUMIDITY = $scope.thRecords["minHumidity"];
    	$scope.MINHUMIDITYDATE = $scope.thRecords["minHumidityDate"].split(" ")[0];
    	$scope.DATERANGE = $scope.thRecords["fromDate"].split(" ")[0]+" - "+$scope.thRecords["toDate"].split(" ")[0];
    	
    	// Set min and max date ranges for date picker event
    	var fromDateArr = $scope.thRecords["fromDate"].split(" ")[0].split("-");
    	$scope.fromDate = new Date(fromDateArr[0],fromDateArr[1],fromDateArr[2]);
    	var toDateArr = $scope.thRecords["toDate"].split(" ")[0].split("-");
    	$scope.toDate = new Date(toDateArr[0],toDateArr[1],toDateArr[2]);
    	
    	// Draw the chart
	    google.charts.load('current', {'packages':['annotationchart']});
		google.charts.setOnLoadCallback($scope.drawTHChart);
    });
    
    // Function to draw Annotation Chart
    $scope.drawTHChart = function() {
    	// console.log("Inside dashboardController drawChart");
    	
    	var rowArr = [];
    	var jsonArr = $scope.thRecords;
    	
    	for(i=0;i<jsonArr["rows"].length;i++) {
    		var dateTimeArr = jsonArr["rows"][i]["datetime"].split(" ");
    		var dateArr = dateTimeArr[0].split("-");
    		var timeArr = dateTimeArr[1].split(":");
    		
    		// console.log(i+") "+dateArr[0]+"/"+dateArr[1]+"/"+dateArr[2]);
    		var currDate = new Date(dateArr[0],dateArr[1],dateArr[2]);
    		if(currDate >= $scope.fromDate && currDate <=$scope.toDate) {
        		var tempArr = [];
        		// console.log(i+" Included");
        		tempArr[0] = new Date(dateArr[0],dateArr[1],dateArr[2],timeArr[0],timeArr[1],timeArr[2]);
        		tempArr[1] = Number(jsonArr["rows"][i]["temparature"]);
        		tempArr[2] = Number(jsonArr["rows"][i]["humidity"]);
        		rowArr[i] = tempArr;
    		}
    	}
    	
        $scope.data = new google.visualization.DataTable();
        $scope.data.addColumn('date', 'Date');
        $scope.data.addColumn('number', 'Temparature');
        $scope.data.addColumn('number', 'Humidity');
        $scope.data.addRows(rowArr);
        /*data.addRows([
          [new Date(2314, 2, 15, 23, 12, 05), 12400,10645],
          [new Date(2314, 2, 16, 11, 16, 30), 24045,12374]
        ]);*/

        // Clear the content of div every time , before re-drawing
        document.getElementById('canvas_dahs').innerHTML = "";
        
        var chart = new google.visualization.AnnotationChart(document.getElementById('canvas_dahs'));

        var options = {
          displayAnnotations: true,
          colors: ["red","blue"]
          //,fill : 50
        };

        chart.draw($scope.data, options);
    };
    
    // Resize Function - Only to re-draw the chart if the browser window resizes
    var w = angular.element($window);
    w.bind('resize', function () {
    	// console.log("Inside dashboardController resize");
	    google.charts.load('current', {'packages':['annotationchart']});
		google.charts.setOnLoadCallback($scope.drawTHChart);   	
    } 
    );
    
    // console.log("Inside dashboardController Before Calander");
    // Date Range Settings - Starts
    var cb = function(start, end, label) {
        // console.log(start.toISOString(), end.toISOString(), label);
        // $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        $('#reportrange span').html(start.format('YYYY-MM-DD') + ' - ' + end.format('YYYY-MM-DD'));
      };

      var optionSet1 = {
        startDate: moment().subtract(29, 'days'),
        endDate: moment(),
        // minDate: '01/01/2012',
        minDate: '2012-01-01',
        // maxDate: '12/31/2015',
        maxDate: '2015-31-12',
        dateLimit: {
          days: 60
        },
        showDropdowns: true,
        showWeekNumbers: true,
        timePicker: false,
        timePickerIncrement: 1,
        timePicker12Hour: true,
        ranges: {
          'Today': [moment(), moment()],
          'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days': [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month': [moment().startOf('month'), moment().endOf('month')],
          'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        opens: 'left',
        buttonClasses: ['btn btn-default'],
        applyClass: 'btn-small btn-primary',
        cancelClass: 'btn-small',
        // format: 'MM/DD/YYYY',
        format: 'YYYY-MM-DD',
        separator: ' to ',
        locale: {
          applyLabel: 'Submit',
          cancelLabel: 'Clear',
          fromLabel: 'From',
          toLabel: 'To',
          customRangeLabel: 'Custom',
          daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
          monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
          firstDay: 1
        }
      };
      // $('#reportrange span').html(moment().subtract(29, 'days').format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));
      $('#reportrange span').html(moment().subtract(29, 'days').format('YYYY-MM-DD') + ' - ' + moment().format('YYYY-MM-DD'));
      $('#reportrange').daterangepicker(optionSet1, cb);
      $('#reportrange').on('show.daterangepicker', function() {
        // console.log("show event fired");
      });
      $('#reportrange').on('hide.daterangepicker', function() {
        // console.log("hide event fired");
      });
      $('#reportrange').on('apply.daterangepicker', function(ev, picker) {
        // // console.log("apply event fired, start/end dates are " + picker.startDate.format('MMMM D, YYYY') + " to " + picker.endDate.format('MMMM D, YYYY'));
    	  // console.log("apply event fired, start/end dates are " + picker.startDate.format('YYYY/MM/DD') + " to " + picker.endDate.format('YYYY/MM/DD'));
    	  
      	// Set min and max date ranges for date picker event
      	var fromDateArr = picker.startDate.format('YYYY-MM-DD').split("-");
      	$scope.fromDate = new Date(fromDateArr[0],fromDateArr[1],fromDateArr[2]);
      	var toDateArr = picker.endDate.format('YYYY-MM-DD').split("-");
      	$scope.toDate = new Date(toDateArr[0],toDateArr[1],toDateArr[2]);
      	
      	// Set the Date Range for calander text box 
      	$scope.DATERANGE = picker.startDate.format('YYYY-MM-DD')+" - "+picker.endDate.format('YYYY-MM-DD');
      	
        $http.get("util.php?method=getTempNHumidData&startDate="+picker.startDate.format('YYYY-MM-DD')+"&endDate="+picker.endDate.format('YYYY-MM-DD'))
        .then(function(response) {
        	// console.log("Inside dashboardController http get : "+response.data);	
        	
        	$scope.thRecords = JSON.parse(response.data);
            
        	$scope.MAXTEMP = $scope.thRecords["maxTemp"];
        	$scope.MAXTEMPDATE = $scope.thRecords["maxTempDate"].split(" ")[0];
        	$scope.MAXHUMIDITY = $scope.thRecords["maxHumidity"];
        	$scope.MAXHUMIDITYDATE = $scope.thRecords["maxHumidityDate"].split(" ")[0];
        	$scope.MINTEMP = $scope.thRecords["minTemp"];
        	$scope.MINTEMPDATE = $scope.thRecords["minTempDate"].split(" ")[0];
        	$scope.MINHUMIDITY = $scope.thRecords["minHumidity"];
        	$scope.MINHUMIDITYDATE = $scope.thRecords["minHumidityDate"].split(" ")[0];
        	
        	// Re-call the chart drawing function
    	    google.charts.load('current', {'packages':['annotationchart']});
    		google.charts.setOnLoadCallback($scope.drawTHChart);
        });  
      	
      });
      $('#reportrange').on('cancel.daterangepicker', function(ev, picker) {
        // console.log("cancel event fired");
      });
      $('#options1').click(function() {
        $('#reportrange').data('daterangepicker').setOptions(optionSet1, cb);
      });
      $('#options2').click(function() {
        $('#reportrange').data('daterangepicker').setOptions(optionSet2, cb);
      });
      $('#destroy').click(function() {
        $('#reportrange').data('daterangepicker').remove();
      });
    // Date Range Settings - Ends
    
    
     // Pubnub Subscriber for temparature and Humidity Dashboard - Starts
      var pubnub = new PubNub({
  	    subscribeKey: "sub-c-24840304-c741-11e6-b8a7-0619f8945a4f"
  	  });
      console.log("Created Pubnub object");
  	  console.log("Created Pubnub Listener");
  	  pubnub.addListener({
  	    message: function(m) {
  	        // handle message
  	        console.log(m.message);
  	        json = m.message;
  	        
  	        newDate = json["Date"];
  	        newTemp = json["Temparature"];
  	        newHumid = json["Humidity"];
  	        console.log(newDate);
  	        console.log(newTemp);
  	        console.log(newHumid);
  	        
  	        var resArr = newDate.split(" ");
  	        var dateArr = resArr[0].split("-");
  	        // var timeArr = resArr[1].split(":");
  	        
  	        var evtDate = new Date(dateArr[0],dateArr[1],dateArr[2]);
  	        
  	        if(evtDate >= $scope.fromDate && evtDate <= $scope.toDate) {
  	        	if(newTemp >= $scope.MAXTEMP) {
  	        		$scope.MAXTEMP = newTemp;
  	        		$scope.MAXTEMPDATE = resArr[0];
  	        	}
  	        	if(newTemp <= $scope.MINTEMP) {
  	        		$scope.MINTEMP = newTemp;
  	        		$scope.MINTEMPDATE = resArr[0];
  	        	}
  	        	if(newHumid >= $scope.MAXHUMIDITY) {
  	        		$scope.MAXHUMIDITY  = newHumid;
  	        		$scope.MAXHUMIDITYDATE = resArr[0];
  	        	}
  	        	if(newHumid <= $scope.MINHUMIDITY) {
  	        		$scope.MINHUMIDITY  = newHumid;
  	        		$scope.MINHUMIDITYDATE = resArr[0];
  	        	}
  	  	    	
  	  	        var jsonArr = $scope.thRecords
  	  	        var jsonArrLen = jsonArr["rows"].length;
  	  	        var json = '{"datetime" : "'+newDate+'" , "temparature" : '+newTemp+',"humidity" : '+newHumid+'}';
  	  	        $scope.thRecords["rows"][jsonArrLen] = JSON.parse(json);
  	  	        
  	  	    	// Draw the chart
  	  		    google.charts.load('current', {'packages':['annotationchart']});
  	  			google.charts.setOnLoadCallback($scope.drawTHChart);
  	  	        
  	        }
  	        // console.log("New Temp Humid Arr : "+$scope.thRecords["rows"]);

  	    }
  	  });
  	  console.log("Created Pubnub Subscription");
  	  pubnub.subscribe({
    	channels: ['temp_humid_channel'],
    	withPresence: true // also subscribe to presence instances.
  	  });
	
  	  console.log("After Pubnub Subscription");
      
     // Pubnub Subscriber for temparature and Humidity Dashboard - Ends
  	  
  	 // Pubnub un-subscription on change of view - Starts
  	  $scope.$on('$destroy' , function() {
  		  
  		pubnub.unsubscribe({
  		    channels : ['temp_humid_channel']
  		}); 
  		console.log("Unsubscribing to temp_humid_channel");
  	  });
  	 // Pubnub un-subscription on change of view - Ends
  	  
  	 // Loading Component Status - Starts
      $http.get("util.php?method=getComponentStatus")
      .then(function(response) {
      	console.log("Inside dashboardController http getComponentStatus : "+response.data);	
      	
      	var records = JSON.parse(response.data);
      	
      	var table = $('#componentStatus').DataTable();
      	
      	// console.log(records["rows"]);
      	
      	for(i=0;i<records["rows"].length;i++) {
      		// console.log(records["rows"][i]["Component"] +" == "+ records["rows"][i]["Status"]);
      		table.row.add([records["rows"][i]["Component"], records["rows"][i]["Status"]]).draw(false);
      	}
      	
      	// table.rows.add(records["rows"]).draw(false);
    
      });  
  	 // Loading Component Status - Ends
});