#!/bin/bash
echo "Inside DHT11 Status Script. Status : $1"

if [ $1 -eq 1 ]
then
  sudo nohup python /var/www/html/RASPi/tempHumidDatamain.py >/dev/null 2>&1 &
  echo "Connected to DHT11"
elif [ $1 -eq 0 ]
then
  ps -ef | grep -v grep | grep tempHumidDatamain.py | awk '{print $2}' | sudo xargs kill -9
  echo "Disconnected from DHT11"
fi