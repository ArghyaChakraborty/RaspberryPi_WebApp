<?php
/*##############################################################################################
# Filename      : log4j.php
# Description	: This program will define the class for logger to be used in all 
#				  application files
################################################################################################ */
$ini_array = parse_ini_file("config.ini");

if($ini_array === false) {
	return false;
}
$appFolder	= $ini_array['APP_PATH'];

include "$appFolder" . "log4php/Logger.php";

// Tell log4php to use our configuration file.
Logger::configure("$appFolder". "resources/configurator_log4j.xml");

$logObj = Logger::getLogger('main');





?>