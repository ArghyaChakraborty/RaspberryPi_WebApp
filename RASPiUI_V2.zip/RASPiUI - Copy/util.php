<?php
include_once 'log4j.php';
include_once 'DBConnect.class.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Check all the oncoming request here ....
if(array_key_exists("method", $_GET)) {
	if($_GET["method"] == "getLEDStatus") {
		echo getLEDStatus();
	} else if($_GET["method"] == "setLEDStatus") {
		echo setLEDStatus($_GET["ledStatus"]);
	} 
	else if($_GET["method"] == "getTempNHumidData") {
		$startDate = "";
		$startTime = "";
		$endDate = "";
		$endTime = "";
		if(array_key_exists("startDate", $_GET) && strlen($_GET["startDate"]) != 0) {
			$startDate = $_GET["startDate"];
		}
		if(array_key_exists("startTime", $_GET) && strlen($_GET["startTime"]) != 0) {
			$startTime = $_GET["startTime"];
		}
		if(array_key_exists("endDate", $_GET) && strlen($_GET["endDate"]) != 0) {
			$endDate = $_GET["endDate"];
		}
		if(array_key_exists("endTime", $_GET) && strlen($_GET["endTime"]) != 0) {
			$endTime = $_GET["endTime"];
		}
		echo getTempNHumidData($startDate,$startTime,$endDate,$endTime);
	}
	else if($_GET["method"] == "logAction") {
		echo logAction($_GET["message"],$_GET["note"]);
	}
	else if($_GET["method"] == "getPastActions") {
		echo getPastActions();
	}
	else if($_GET["method"] == "actOnRaspi") {
		echo actOnRaspi($_GET["action"]);
	}
	else if($_GET["method"] == "executeCommand") {
		echo executeCommand($_GET["command"]);
	}
	else if($_GET["method"] == "getComponentStatus") {
		echo getComponentStatus(); 
	}
	else if($_GET["method"] == "setDHTStatus") {
		echo setDHTStatus($_GET["status"]);
	}
	else if($_GET["method"] == "getDHT11Status") {
		echo getDHT11Status();
	}
}

// All function definitions go here ..
// Function to get LED Status
function getLEDStatus() {
	global $ini_array , $logObj;
	$logObj->debug("Inside getLEDStatus");
	$db = new DBConnect($ini_array, $logObj);
	$ledStatus = $db->fetchRows($ini_array['DB_STATUS_TABLE'],array('Status'),"Component = 'LED'");
	$ledStatus = $ledStatus[0]['Status'];
	
	// $ledStatus = file_get_contents($ini_array["LED_STATUS_FILE"]);
	$logObj->debug("LED Status = "+$ledStatus);
	return json_encode('{"status" : "'.$ledStatus.'"}');
}

// Function to get DHT11 Status
function getDHT11Status() {
	global $ini_array , $logObj;
	$logObj->debug("Inside getDHT11Status");
	$db = new DBConnect($ini_array, $logObj);
	$dhtStatus = $db->fetchRows($ini_array['DB_STATUS_TABLE'],array('Status'),"Component = 'DHT11'");
	$dhtStatus = $dhtStatus[0]['Status'];
	
	// $ledStatus = file_get_contents($ini_array["LED_STATUS_FILE"]);
	$logObj->debug("DHT11 Status = ".$dhtStatus);
	return json_encode('{"status" : "'.$dhtStatus.'"}');
}

// Function to set LED Status
function setLEDStatus($status) {
		// $status = true / false
	global $ini_array , $logObj;
	$logObj->debug("Inside setLEDStatus :  status : ".$status);
	
	$pyCommand = "sudo ".$ini_array["PYTHON_PATH"]." ".$ini_array["SET_LED_STATUS_SCRIPT"]." ";
	$returnValue = "";
	if($status == "on") {
		exec($pyCommand."on", $output, $retVal);
		$logObj->debug("Tried to swich on the LED.\nScript O/P : ".print_r($output,true)."\nScript Status : ".$retVal);
		$returnValue = "on";
	} else if ($status == "off"){
		exec($pyCommand."off", $output, $retVal);
		$logObj->debug("Tried to swich off the LED.\nScript O/P : ".print_r($output,true)."\nScript Status : ".$retVal);
		$returnValue = "off";
	}
	
	$db = new DBConnect($ini_array, $logObj);
	$db->query("UPDATE ".$ini_array['DB_STATUS_TABLE']." SET Status = '".$returnValue."' WHERE Component = 'LED'");

	/*
	$fp = fopen($ini_array["LOCK_FILE"], "w");
	$returnValue = "";

	if (! flock($fp, LOCK_EX)) {  // acquire an exclusive lock
		$logObj->debug("Unable to acquire lock ....");
    	$returnValue = "Sorry ... someone else is trying to light the LED .....";
	} else {
		$pyCommand = "sudo ".$ini_array["PYTHON_PATH"]." ".$ini_array["SET_LED_STATUS_SCRIPT"]." ";
		$f2w = fopen($ini_array["LED_STATUS_FILE"], "w");
	
		if($status == "on") {
			exec($pyCommand."on", $output, $retVal);
			$logObj->debug("Tried to swich on the LED.\nScript O/P : ".print_r($output,true)."\nScript Status : ".$retVal);
			fwrite($f2w, "on");
			$returnValue = "on";
		} else if ($status == "off"){
			exec($pyCommand."off", $output, $retVal);
			$logObj->debug("Tried to swich off the LED.\nScript O/P : ".print_r($output,true)."\nScript Status : ".$retVal);
			fwrite($f2w, "off");
			$returnValue = "off";
		}
	
		fclose($f2w);
		fclose($fp);
    	flock($fp, LOCK_UN);    // release the lock
    	fclose($fp);	
	}
	*/
	return json_encode('{"status" : "'.$returnValue.'"}');
}

// Function to retrieve Time Series Data from DB
function getTempNHumidData($startDate="",$startTime="",$endDate="",$endTime="") {
	global $ini_array , $logObj;
	$logObj->debug("Inside getTempNHumidData");
	
	$whereCondition = "";
	if(strlen($startDate) == 0) {
		$startDate = date("Y-m-d",strtotime($ini_array["TNH_DATA_RANGE"]));
	} 
	if(strlen($endDate) == 0) {
		$endDate = date("Y-m-d");
	}
	if(strlen($startTime) == 0) {
		$startTime = "00:00:00";
	}
	if(strlen($endTime) == 0) {
		$endTime = "23:59:59";
	}
	
	if(array_key_exists("TNH_DATA_RANGE", $ini_array) && strlen(trim($ini_array["TNH_DATA_RANGE"])) != 0) {
		$whereCondition = "datetime >= '".$startDate." ".$startTime."' AND datetime <= '".$endDate." ".$endTime."'";
	}
	
	$db = new DBConnect($ini_array, $logObj);
	
	// Temparature and Humidity Records
	$logObj->debug("Temp & Humidity Records");
	$tnhRecords = $db->fetchRows($ini_array['DB_TABLE_NAME_TNH'],array(),$whereCondition);
	
	// Maximum Temparature & Date in which Max Temp occured
	$logObj->debug("Max Temp , Min Temparature , Max Humidity , Min Humidity");
	$tnhAggregate = $db->fetchRows($ini_array['DB_TABLE_NAME_TNH'],array('max(temparature)','min(temparature)' ,'max(humidity)','min(humidity)'),$whereCondition);
	$maxTemp = $tnhAggregate[0]['max(temparature)'];
	$minTemp = $tnhAggregate[0]['min(temparature)'];
	$maxHumidity = $tnhAggregate[0]['max(humidity)'];
	$minHumidity = $tnhAggregate[0]['min(humidity)'];
	
	$logObj->debug("Max Temp Date");
	$maxTempDate = "";
	if(strlen($whereCondition) != 0) {
		$maxTempDate = $db->fetchRows($ini_array['DB_TABLE_NAME_TNH'],array('max(datetime)'),$whereCondition.' AND temparature = '.$maxTemp);
	} else {
		$maxTempDate = $db->fetchRows($ini_array['DB_TABLE_NAME_TNH'],array('max(datetime)'),'temparature = '.$maxTemp);
	}
	$maxTempDate = $maxTempDate[0]['max(datetime)'];
	
	// Minimum Temparature & Date in which Min Temp occured
	// $logObj->debug("Min Temp");
	// $minTemp = $db->fetchRows($ini_array['DB_TABLE_NAME_TNH'],array('min(temparature)'),$whereCondition);
	// $minTemp = $minTemp[0]['min(temparature)'];
	$logObj->debug("Min Temp Date");
	$minTempDate = "";
	if(strlen($whereCondition) != 0) {
		$minTempDate = $db->fetchRows($ini_array['DB_TABLE_NAME_TNH'],array('max(datetime)'),$whereCondition.' AND temparature = '.$minTemp);
	} else {
		$minTempDate = $db->fetchRows($ini_array['DB_TABLE_NAME_TNH'],array('max(datetime)'),'temparature = '.$minTemp);
	}
	$minTempDate = $minTempDate[0]['max(datetime)'];
	
	// Maximum Humidity & Date in which Max Humidity Occured
	// $logObj->debug("Max Humidity");
	// $maxHumidity = $db->fetchRows($ini_array['DB_TABLE_NAME_TNH'],array('max(humidity)'),$whereCondition);
	// $maxHumidity = $maxHumidity[0]['max(humidity)'];
	$logObj->debug("Max Humidity Date");
	$maxHumidityDate = "";
	if(strlen($whereCondition) != 0) {
		$maxHumidityDate = $db->fetchRows($ini_array['DB_TABLE_NAME_TNH'],array('max(datetime)'),$whereCondition.' AND humidity = '.$maxHumidity);
	} else {
		$maxHumidityDate = $db->fetchRows($ini_array['DB_TABLE_NAME_TNH'],array('max(datetime)'),'humidity = '.$maxHumidity);
	}
	$maxHumidityDate = $maxHumidityDate[0]['max(datetime)'];
	
	// Minimum Humidity & Date in which Min Humidity Occured
	// $logObj->debug("Min Humidity");
	// $minHumidity = $db->fetchRows($ini_array['DB_TABLE_NAME_TNH'],array('min(humidity)'),$whereCondition);
	// $minHumidity = $minHumidity[0]['min(humidity)'];
	$logObj->debug("Min Humidity Date");
	$minHumidityDate = "";
	if(strlen($whereCondition) != 0) {
		$minHumidityDate = $db->fetchRows($ini_array['DB_TABLE_NAME_TNH'],array('max(datetime)'),$whereCondition.' AND humidity = '.$minHumidity);
	} else {
		$minHumidityDate = $db->fetchRows($ini_array['DB_TABLE_NAME_TNH'],array('max(datetime)'),'humidity = '.$minHumidity);
	}
	$minHumidityDate = $minHumidityDate[0]['max(datetime)'];
	
	$jsonData = '{';
	if(count($tnhRecords) == 0) {
		$jsonData.= '"rows" : []';
	} else {
		$jsonData.= '"rows" : '.json_encode($tnhRecords);
	}
	$jsonData .= ',"maxTemp" : "'.$maxTemp.'"';
	$jsonData .= ',"minTemp" : "'.$minTemp.'"';
	$jsonData .= ',"maxHumidity" : "'.$maxHumidity.'"';
	$jsonData .= ',"minHumidity" : "'.$minHumidity.'"';
	$jsonData .= ',"maxTempDate" : "'.$maxTempDate.'"';
	$jsonData .= ',"minTempDate" : "'.$minTempDate.'"';
	$jsonData .= ',"maxHumidityDate" : "'.$maxHumidityDate.'"';
	$jsonData .= ',"minHumidityDate" : "'.$minHumidityDate.'"';
	$jsonData .= ',"fromDate" : "'.$startDate.'"';
	$jsonData .= ',"toDate" : "'.$endDate.'"';
	$jsonData .= '}';
	
	/*
	$jsonData = '{';
	$jsonData .= '"rows" : [{"year" : 2016,"month" : 12,"date" : 13,"hour" : 10,"min" : 20,"sec" : 30,"temp" : -15,"humidity" : 30},{"year" : 2016,"month" : 12,"date" : 13,"hour" : 11,"min" : 20,"sec" : 30,"temp" : -14,"humidity" : 35},{"year" : 2016,"month" : 12,"date" : 13,"hour" : 12,"min" : 20,"sec" : 30,"temp" : -15.2,"humidity" : 35},{"year" : 2016,"month" : 12,"date" : 13,"hour" : 12,"min" : 20,"sec" : 30,"temp" : -15.2,"humidity" : 33},{"year" : 2016,"month" : 12,"date" : 15,"hour" : 12,"min" : 20,"sec" : 30,"temp" : -15.2,"humidity" : 33}]';
	$jsonData .= ',"maxTemp" : -14';
	$jsonData .= ',"minTemp" : -15.2';
	$jsonData .= ',"maxHumidity" : 35';
	$jsonData .= ',"minHumidity" : 30';
	$jsonData .= ',"maxTempDate" : "2016-12-13"';
	$jsonData .= ',"minTempDate" : "2016-12-13"';
	$jsonData .= ',"maxHumidityDate" : "2016-12-13"';
	$jsonData .= ',"minHumidityDate" : "2016-12-13"';
	$jsonData .= ',"fromDate" : "2016--12-13"';
	$jsonData .= ',"toDate" : "2016-12-15"';
	$jsonData .= '}';
	*/
	
	$logObj->debug("TNH JSON : ".$jsonData);
	
	return json_encode($jsonData);
}

// Function to write Action Details to DB
function logAction($message, $note) {
	global $logObj , $ini_array;
	$logObj->debug("inside PHP logAction");
	$currDate = date("Y-m-d H:i:s");
	$ip = "";
	
	if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	} else {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	
	$logObj->debug("inside PHP logAction ".$currDate." =========== ".$ip);
	
	$db = new DBConnect($ini_array, $logObj);
	$rowArray = array();
	$tempArray = array();
	$tempArray['date'] = $currDate;
	$tempArray['ip'] = $ip;
	$tempArray['action'] = $message;
	if(strlen($note) != 0) {
		$tempArray['note'] = $note;
	}
	
	$rowArray[] = $tempArray;
	
	$retNote = "";
	if(!$db->insertRows($ini_array['DB_TABLE_NAME'], $rowArray)) {
		$retNote = "Logging Failed";
	} else {
		$retNote = "NA";
	}
	
	$retval = '{"date" : "'.$currDate.'" , "ip" : "'.$ip.'" , "note" : "'.$retNote.'"}';
	$logObj->debug("retVal = ".$retval);
	return json_encode($retval);
} 

// Function for initial load of all existing audit data
function getPastActions() {
	global $logObj,$ini_array;
	$logObj->debug("Inside getPastActions");
	
	// Code to retrieve data from DB goes here
	$db = new DBConnect($ini_array, $logObj);
	$fetchedRows = $db->fetchRows($ini_array['DB_TABLE_NAME']);
	
	$pastActions = "";
	
	if($fetchedRows === FALSE || count($fetchedRows) == 0) {
		$pastActions = '{"actions" : []}';
	} else {
		$pastActions = '{"actions" : '.json_encode($fetchedRows).'}';
	}
	
	/*
	$pastActions = '{"actions" : [';
	$pastActions .= '{"dateTime" : "2016-12-13 12:00:00" , "ip" : "127.0.0.1" , "message" : "Dummy1" , "note" : "NA"}';
	$pastActions .= ' , {"dateTime" : "2016-12-14 12:00:00" , "ip" : "127.0.0.1" , "message" : "Dummy2" , "note" : "NA"}';
	$pastActions .= ']}';
	*/
	
	$logObj->debug("Past Actions JSON : ".$pastActions);
	
	return json_encode($pastActions);
}

// Function to perform action on Raspberry Pi
function actOnRaspi($action) {
	// Code to act on Raspberry PI go here
	global $logObj, $ini_array;
	$logObj->debug("Inside actOnRaspi .. Action : ".$action);
	$pyCommand = "sudo ".$ini_array["PYTHON_PATH"]." ".$ini_array["RASPI_ACTION_SCRIPT"]." ".$action;
	$logObj->debug("Raspi Action Command : ".$pyCommand);
	exec($pyCommand, $output, $retVal);
	$logObj->debug("Raspi Action Command RetCode: ".$retVal." , Output : ".$output);
	return json_encode('{}');
}


// Function to execute shell command
function executeCommand($cmd) {
	global $ini_array , $logObj;
	$logObj->debug("Inside execute Command : ".$cmd);
	exec(trim($cmd),$output,$retVal);
	$logObj->debug("Command Return value : ".$retVal);
	$logObj->debug("Command O/P : ".$output);
	
	$buffer = array();
	foreach($output as $index=>$val) {
		$buffer[] = '{"line" : "'.trim(htmlentities($val)).'"}';
	}
	
	
	return json_encode('{"output" : ['.implode(",", $buffer).']}');
}

// Function to get Component Status
function getComponentStatus() {
	global $ini_array , $logObj;
	$logObj->debug("Inside getComponentStatus");
	
	$db = new DBConnect($ini_array, $logObj);
	$rows = $db->fetchRows($ini_array["DB_STATUS_TABLE"]);
	$retVal = "";
	if($rows === FALSE || count($rows) == 0) {
		$retVal = '{"rows" : []}';	
	} else {
		$retVal = '{"rows" : '.json_encode($rows).'}';
	}
	
	$logObj->debug("Return Value : ".$retVal);
	
	return json_encode($retVal);
}

// Function to Change DHT Connection Status
function setDHTStatus($status) {
	global $ini_array , $logObj;
	$logObj->debug("Inside setDHTStatus : ".$status);

	if($status == "connected") {
		exec($ini_array["DHT11_CONNECT_COMMAND"],$output,$retVal);
		$logObj->debug("Tried to Start DHT11 O/P : ".print_r($output,true)." & retVal : ".$retVal);
	} else if($status == "disconnected") {
		exec($ini_array["DHT11_DISCONNECT_COMMAND"],$output,$retVal);
		$logObj->debug("Tried to Shut Down DHT11 O/P : ".print_r($output,true)." & retVal : ".$retVal);		
	}
	
	$db = new DBConnect($ini_array, $logObj);
	$db->query("UPDATE ".$ini_array['DB_STATUS_TABLE']." SET Status = '".$status."' WHERE Component = 'DHT11'");
	
	return json_encode('{"status" : "'.$status.'"}');
}

?>