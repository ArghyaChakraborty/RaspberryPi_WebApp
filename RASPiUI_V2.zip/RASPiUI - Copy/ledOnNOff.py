import time, sys, RPi.GPIO as GPIO
from ConfigParser import ConfigParser

config = ConfigParser()
config.readfp(open("config.ini"))
PINNUM = int(config.get("Python_LED", "LED_PIN"))

GPIO.setmode(GPIO.BCM)

GPIO.setup(PINNUM ,GPIO.OUT)

GPIO.setwarnings(False)

try :
    if(sys.argv[1] == "on") :
        GPIO.output(PINNUM, True)
    elif(sys.argv[1] == "off") :
        GPIO.output(PINNUM, False)    
except Exception as ex :
    print("Got Exception : "+ex)